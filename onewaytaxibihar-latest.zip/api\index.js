/**
 * OneWayTaxiBihar (onewaytaxibihar.com)
 * Unified Production Serverless REST API Handler for Vercel
 * OneWayTaxiBihar Mobility Pvt Ltd
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// Resolve database path (supports local repo and Vercel /tmp)
const DB_LOCAL_PATH = path.join(process.cwd(), 'data', 'db.json');
const DB_TMP_PATH = '/tmp/db.json';
const activeVerificationCodes = new Map();
const activeAdminOtps = new Map();

function getDbPath() {
  if (process.env.VERCEL) {
    if (!fs.existsSync(DB_TMP_PATH)) {
      if (fs.existsSync(DB_LOCAL_PATH)) {
        try {
          fs.copyFileSync(DB_LOCAL_PATH, DB_TMP_PATH);
        } catch (e) {
          console.warn('[DB] Failed to seed /tmp/db.json:', e.message);
        }
      }
    }
    return DB_TMP_PATH;
  }
  return DB_LOCAL_PATH;
}

// In-memory fallback for high-concurrency serverless execution
let memoryDb = null;

function loadDb() {
  try {
    const targetPath = getDbPath();
    if (fs.existsSync(targetPath)) {
      const data = fs.readFileSync(targetPath, 'utf8').replace(/^\uFEFF/, '');
      memoryDb = JSON.parse(data);
      return memoryDb;
    }
  } catch (e) {
    console.warn('[DB] File read failed, using memory DB:', e.message);
  }

  if (!memoryDb) {
    memoryDb = {
      users: [],
      sessions: [],
      bookings: [],
      drivers: [
        {
          id: "drv_101",
          name: "Ramesh Kumar Sharma",
          phone: "+91 94310 12345",
          pin: "1234",
          vehicleNumber: "BR 01 PA 4921",
          vehicleModel: "Swift Dzire (White)",
          fleetTier: "sedan",
          rating: 4.9,
          totalTrips: 342,
          status: "Available"
        },
        {
          id: "drv_102",
          name: "Amit Kumar Singh",
          phone: "+91 98350 67890",
          pin: "5678",
          vehicleNumber: "BR 01 PB 7712",
          vehicleModel: "Maruti Ertiga (Silver)",
          fleetTier: "suv",
          rating: 4.85,
          totalTrips: 286,
          status: "Available"
        }
      ],
      payments: [],
      wallet_ledger: [],
      audit_logs: [],
      admins: [
        {
          id: "adm_01",
          username: "admin",
          passwordHash: "8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918", // admin123
          name: "Patna Central Dispatch",
          role: "SUPER_ADMIN"
        }
      ],
      reviews: [],
      leads: []
    };
  }
  return memoryDb;
}

let mongoClientInstance = null;
async function syncToMongoAsync(db) {
  const uri = process.env.MONGODB_URI;
  if (!uri) return;
  try {
    const { MongoClient } = require('mongodb');
    if (!mongoClientInstance) {
      mongoClientInstance = new MongoClient(uri, { serverSelectionTimeoutMS: 5000 });
      await mongoClientInstance.connect();
    }
    const mdb = mongoClientInstance.db(process.env.MONGODB_DB_NAME || 'onewaytaxibihar');
    if (Array.isArray(db.users)) {
      for (const u of db.users) {
        if (u.id) await mdb.collection('users').updateOne({ id: u.id }, { $set: u }, { upsert: true });
      }
    }
    if (Array.isArray(db.bookings)) {
      for (const b of db.bookings) {
        const bId = b.bookingId || b.id;
        if (bId) await mdb.collection('bookings').updateOne({ bookingId: bId }, { $set: { ...b, bookingId: bId } }, { upsert: true });
      }
    }
  } catch (err) {
    console.warn('[MongoDB Atlas] Async sync notice:', err.message);
  }
}

function saveDb(db) {
  memoryDb = db;
  try {
    const targetPath = getDbPath();
    const dir = path.dirname(targetPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(targetPath, JSON.stringify(db, null, 2), 'utf8');
    // Asynchronous push to MongoDB Atlas online cloud
    syncToMongoAsync(db).catch(() => {});
  } catch (e) {
    console.warn('[DB] File save failed (using in-memory):', e.message);
  }
}

let memoryCities = null;
function loadCities() {
  if (memoryCities) return memoryCities;
  try {
    const cPath = path.join(process.cwd(), 'data', 'cities.json');
    if (fs.existsSync(cPath)) {
      memoryCities = JSON.parse(fs.readFileSync(cPath, 'utf8').replace(/^\uFEFF/, ''));
      return memoryCities;
    }
  } catch (e) {
    console.warn('[DB] Failed to load cities.json:', e.message);
  }
  return [];
}

let memoryLocations = null;
function loadLocations() {
  if (memoryLocations) return memoryLocations;
  try {
    const lPath = path.join(process.cwd(), 'data', 'locations.json');
    if (fs.existsSync(lPath)) {
      memoryLocations = JSON.parse(fs.readFileSync(lPath, 'utf8').replace(/^\uFEFF/, ''));
      return memoryLocations;
    }
  } catch (e) {
    console.warn('[DB] Failed to load locations.json:', e.message);
  }
  return [];
}

// 38 Districts of Bihar + Major Intercity Transit Hubs Coordinates
const BIHAR_COORDS = {
  "patna": [25.5941, 85.1376],
  "nalanda": [25.1978, 85.5186],
  "biharsharif": [25.1978, 85.5186],
  "rajgir": [25.0300, 85.4200],
  "bhojpur": [25.5541, 84.6644],
  "ara": [25.5541, 84.6644],
  "buxar": [25.5647, 83.9777],
  "rohtas": [24.9536, 84.0159],
  "sasaram": [24.9536, 84.0159],
  "dehri": [24.9167, 84.1833],
  "kaimur": [25.0450, 83.6144],
  "bhabua": [25.0450, 83.6144],
  "gaya": [24.7914, 85.0002],
  "bodhgaya": [24.6961, 84.9870],
  "aurangabad": [24.7539, 84.3742],
  "nawada": [24.8872, 85.5433],
  "jehanabad": [25.2136, 84.9867],
  "arwal": [25.2444, 84.6789],
  "muzaffarpur": [26.1209, 85.3647],
  "vaishali": [25.6858, 85.2155],
  "hajipur": [25.6858, 85.2155],
  "eastchamparan": [26.6469, 84.9089],
  "motihari": [26.6469, 84.9089],
  "westchamparan": [26.8024, 84.5028],
  "bettiah": [26.8024, 84.5028],
  "sitamarhi": [26.5978, 85.4892],
  "sheohar": [26.5167, 85.2833],
  "darbhanga": [26.1542, 85.8918],
  "madhubani": [26.3533, 86.0718],
  "samastipur": [25.8628, 85.7811],
  "saran": [25.7796, 84.7499],
  "chhapra": [25.7796, 84.7499],
  "siwan": [26.2196, 84.3567],
  "gopalganj": [26.4687, 84.4442],
  "bhagalpur": [25.2425, 87.0125],
  "banka": [24.8833, 86.9167],
  "munger": [25.3750, 86.4744],
  "jamui": [24.9167, 86.2167],
  "khagaria": [25.5000, 86.4833],
  "lakhisarai": [25.1833, 86.0833],
  "sheikhpura": [25.1333, 85.8500],
  "begusarai": [25.4182, 86.1272],
  "purnia": [25.7771, 87.4753],
  "katihar": [25.5394, 87.5661],
  "araria": [26.1500, 87.5167],
  "kishanganj": [26.0744, 87.9400],
  "saharsa": [25.8833, 86.6000],
  "madhepura": [25.9167, 86.7833],
  "supaul": [26.1167, 86.6000],
  "varanasi": [25.3176, 82.9739],
  "deoghar": [24.4826, 86.7001],
  "ranchi": [23.3441, 85.3096],
  "siliguri": [26.7271, 88.3953],
  "gorakhpur": [26.7606, 83.3732],
  "kolkata": [22.5726, 88.3639]
};

// Verified Highway Distance Matrix for Major Routes
const BIHAR_DISTANCES = {
  "patna_gaya": 104,
  "patna_muzaffarpur": 75,
  "patna_darbhanga": 142,
  "patna_bhagalpur": 235,
  "patna_purnia": 305,
  "patna_rajgir": 102,
  "patna_ara": 54,
  "patna_buxar": 130,
  "patna_sasaram": 150,
  "patna_begusarai": 125,
  "patna_chhapra": 50,
  "patna_motihari": 155,
  "patna_bettiah": 200,
  "patna_siwan": 135,
  "patna_samastipur": 88,
  "patna_katihar": 320,
  "patna_saharsa": 210,
  "patna_munger": 178,
  "patna_kishanganj": 395,
  "patna_deoghar": 255,
  "patna_varanasi": 250,
  "patna_ranchi": 325,
  "patna_siliguri": 460
};

function getHaversineDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 1.28); // 1.28x road tortuosity factor for Bihar highway network
}

function resolveCoordinates(name) {
  const clean = (name || "").toLowerCase().replace(/[^a-z]/g, "");
  for (const [key, coords] of Object.entries(BIHAR_COORDS)) {
    if (clean.includes(key) || key.includes(clean)) return coords;
  }
  return null;
}

function getRouteDistance(origin, dest) {
  const normOrigin = (origin || "").toLowerCase().replace(/[^a-z]/g, "");
  const normDest = (dest || "").toLowerCase().replace(/[^a-z]/g, "");

  if (normOrigin === normDest) return 35; // Local intra-city minimum

  const key1 = `${normOrigin}_${normDest}`;
  const key2 = `${normDest}_${normOrigin}`;

  if (BIHAR_DISTANCES[key1]) return BIHAR_DISTANCES[key1];
  if (BIHAR_DISTANCES[key2]) return BIHAR_DISTANCES[key2];

  const coord1 = resolveCoordinates(origin);
  const coord2 = resolveCoordinates(dest);

  if (coord1 && coord2) {
    const dist = getHaversineDistance(coord1[0], coord1[1], coord2[0], coord2[1]);
    return Math.max(dist, 35);
  }

  return 120;
}

// Server-Side Fare Calculation Engine
const FLEET_RATES = {
  hatchback: { baseFare: 850, baseKm: 15, perKm: 21.0, name: "Go Hatchback", model: "WagonR, Tiago" },
  sedan: { baseFare: 1050, baseKm: 15, perKm: 25.0, name: "Prime Sedan", model: "Dzire, Etios, Amaze" },
  sedan_prime: { baseFare: 1350, baseKm: 15, perKm: 29.0, name: "Executive Sedan", model: "Honda City, Ciaz" },
  suv: { baseFare: 1650, baseKm: 15, perKm: 33.0, name: "Family SUV (6+1)", model: "Maruti Ertiga, Carens" }
};

function calculateServerFare(distanceKm, cabTier = 'sedan', tripType = 'oneway', origin = '', dest = '') {
  const tier = FLEET_RATES[cabTier] || FLEET_RATES.sedan;
  const effectiveKm = tripType === 'roundtrip' ? distanceKm * 2 : distanceKm;
  const extraKm = Math.max(0, effectiveKm - tier.baseKm);
  const distanceCharge = Math.round(extraKm * tier.perKm);
  let baseCharge = tier.baseFare + distanceCharge;

  let roundTripDiscount = 0;
  if (tripType === 'roundtrip') {
    roundTripDiscount = Math.round(baseCharge * 0.12);
    baseCharge -= roundTripDiscount;
  }

  const tollEst = Math.round((distanceKm / 70) * 55);
  const driverAllowance = (tripType === 'roundtrip' || distanceKm > 200) ? 350 : 0;
  const normOrigin = (origin || '').toLowerCase();
  const normDest = (dest || '').toLowerCase();
  const parkingCharge = (normOrigin.includes('airport') || normDest.includes('airport')) ? 100 : 0;

  const subtotal = tier.baseFare + distanceCharge - roundTripDiscount + tollEst + driverAllowance + parkingCharge;
  const gst = Math.round(subtotal * 0.05);
  const totalFare = subtotal + gst;

  return {
    distanceKm,
    duration: `${Math.floor(distanceKm / 45)}h ${Math.round((distanceKm % 45) * 1.3)}m`,
    tierId: cabTier,
    tierName: tier.name,
    tierModel: tier.model,
    baseFare: tier.baseFare,
    distanceCharge,
    extraKm,
    perKmRate: tier.perKm,
    roundTripDiscount,
    tollFastag: tollEst,
    parking: parkingCharge,
    driverAllowance,
    gst,
    totalFare: Math.round(totalFare)
  };
}

// Security: Password Hashing & Token Generation
function hashPassword(pass) {
  return crypto.createHash('sha256').update(pass).digest('hex');
}

function generateToken(prefix = 'otb') {
  return `${prefix}_${crypto.randomBytes(16).toString('hex')}`;
}

// Session Validator
function getSessionUser(req, db) {
  const authHeader = req.headers['authorization'] || '';
  const token = authHeader.replace(/^Bearer\s+/i, '').trim();
  if (!token) return null;

  const session = (db.sessions || []).find(s => s.token === token);
  if (!session) return null;

  const user = (db.users || []).find(u => u.id === session.userId || u.phone === session.phone);
  return user ? { user, session } : null;
}

function getSessionAdmin(req, db) {
  const authHeader = req.headers['authorization'] || '';
  const token = authHeader.replace(/^Bearer\s+/i, '').trim();
  if (!token) return null;

  const session = (db.sessions || []).find(s => s.token === token && s.role === 'admin');
  return session || null;
}

function getSessionDriver(req, db) {
  const authHeader = req.headers['authorization'] || '';
  const token = authHeader.replace(/^Bearer\s+/i, '').trim();
  if (!token) return null;

  const session = (db.sessions || []).find(s => s.token === token && s.role === 'driver');
  if (!session) return null;

  const driver = (db.drivers || []).find(d => d.id === session.driverId);
  return driver ? { driver, session } : null;
}

// Main Request Handler
module.exports = async (req, res) => {
  // CORS Headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    res.statusCode = 200;
    return res.end();
  }

  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = url.pathname.replace(/^\/api/, '');
  const method = req.method.toUpperCase();

  // Parse JSON Body
  let body = {};
  if (method === 'POST' || method === 'PUT') {
    try {
      if (req.body && typeof req.body === 'object') {
        body = req.body;
      } else if (typeof req.body === 'string') {
        body = JSON.parse(req.body);
      } else {
        const buffers = [];
        for await (const chunk of req) buffers.push(chunk);
        const data = Buffer.concat(buffers).toString();
        body = data ? JSON.parse(data) : {};
      }
    } catch (e) {
      body = {};
    }
  }

  const db = loadDb();

  const sendJson = (status, data) => {
    res.statusCode = status;
    res.setHeader('Content-Type', 'application/json');
    return res.end(JSON.stringify(data));
  };

  try {
    // -------------------------------------------------------------
    // 1. HEALTHCHECK
    // -------------------------------------------------------------
    if (pathname === '/health' && method === 'GET') {
      return sendJson(200, {
        status: 'ONLINE',
        platform: 'OneWayTaxiBihar Production API',
        domain: 'onewaytaxibihar.com',
        time: new Date().toISOString(),
        helpline: '+91 80021 41816',
        whatsapp: '+91 72818 51011'
      });
    }

    // -------------------------------------------------------------
    // 1B. TUNNEL & NETWORK INFO
    // -------------------------------------------------------------
    if (pathname === '/tunnel-info' && method === 'GET') {
      const tunnelFile = path.join(process.cwd(), 'data', 'tunnel.json');
      if (fs.existsSync(tunnelFile)) {
        try {
          const tData = JSON.parse(fs.readFileSync(tunnelFile, 'utf8'));
          return sendJson(200, tData);
        } catch (e) {}
      }
      return sendJson(200, {
        status: 'ONLINE',
        message: 'OneWayTaxiBihar Production Cloud Server Active',
        helpline: '+91 80021 41816',
        whatsapp: '+91 72818 51011',
        localUrl: 'http://localhost:8080'
      });
    }

    // -------------------------------------------------------------
    // 2A. PASSENGER AUTH: Real Number Verification - Send Code
    // -------------------------------------------------------------
    if (pathname === '/auth/send-otp' && method === 'POST') {
      const cleanPhone = (body.phone || '').replace(/\D/g, '').slice(-10);
      const name = (body.name || '').trim() || 'Valued Passenger';

      if (!cleanPhone || cleanPhone.length !== 10 || !/^[6-9]\d{9}$/.test(cleanPhone)) {
        return sendJson(400, { success: false, message: 'Valid 10-digit Indian mobile number starting with 6-9 required.' });
      }

      const code = Math.floor(1000 + Math.random() * 9000).toString();
      activeVerificationCodes.set(cleanPhone, {
        code,
        name,
        expiresAt: Date.now() + 10 * 60 * 1000,
        attempts: 0
      });

      const existingUser = (db.users || []).find(u => u.phone.replace(/\D/g, '').slice(-10) === cleanPhone);
      const isNewUser = !existingUser;

      const waText = `OneWayTaxiBihar Verification Code for +91 ${cleanPhone} is: ${code}. Valid for 10 minutes. Welcome Reward: Rs 100 on first booking.`;
      const waUrl = `https://wa.me/917281851011?text=${encodeURIComponent(waText)}`;

      return sendJson(200, {
        success: true,
        phone: `+91 ${cleanPhone}`,
        cleanPhone,
        isNewUser,
        rewardEligible: isNewUser,
        rewardAmount: isNewUser ? 100 : 0,
        otpCode: code,
        whatsappUrl: waUrl,
        message: `Verification code dispatched to +91 ${cleanPhone} via SMS & WhatsApp.`
      });
    }

    // -------------------------------------------------------------
    // 2B. PASSENGER AUTH: Real Number Verification - Verify Code & One-Time Reward
    // -------------------------------------------------------------
    if (pathname === '/auth/verify-otp' && method === 'POST') {
      const cleanPhone = (body.phone || '').replace(/\D/g, '').slice(-10);
      const inputCode = (body.otp || '').toString().trim();
      const name = (body.name || '').trim();

      if (!cleanPhone || cleanPhone.length !== 10) {
        return sendJson(400, { success: false, message: 'Valid 10-digit mobile number required.' });
      }

      if (!activeVerificationCodes.has(cleanPhone)) {
        return sendJson(400, { success: false, message: 'No active verification code found. Please request a new code.' });
      }

      const activeRecord = activeVerificationCodes.get(cleanPhone);
      if (Date.now() > activeRecord.expiresAt) {
        activeVerificationCodes.delete(cleanPhone);
        return sendJson(400, { success: false, message: 'Verification code expired. Please request a new code.' });
      }

      if (activeRecord.code !== inputCode) {
        activeRecord.attempts++;
        if (activeRecord.attempts >= 5) {
          activeVerificationCodes.delete(cleanPhone);
          return sendJson(400, { success: false, message: 'Too many incorrect attempts. Please request a new code.' });
        }
        return sendJson(400, { success: false, message: 'Invalid verification code. Please check and re-enter.' });
      }

      activeVerificationCodes.delete(cleanPhone);
      const finalName = name || activeRecord.name || 'Valued Passenger';

      let user = (db.users || []).find(u => u.phone.replace(/\D/g, '').slice(-10) === cleanPhone);
      let isFirstTime = false;
      let rewardGranted = 0;

      if (!user) {
        isFirstTime = true;
        rewardGranted = 100;
        user = {
          id: `usr_${cleanPhone}`,
          name: finalName,
          phone: `+91 ${cleanPhone}`,
          email: (body.email || '').trim().toLowerCase(),
          walletBalance: 100,
          rewardClaimed: true,
          isPhoneVerified: true,
          memberSince: new Date().getFullYear().toString(),
          createdAt: new Date().toISOString()
        };
        db.users.push(user);

        if (!db.wallet_ledger) db.wallet_ledger = [];
        db.wallet_ledger.push({
          id: `WLT_${Date.now()}`,
          userId: user.id,
          phone: user.phone,
          type: 'CREDIT',
          amount: 100,
          balanceAfter: 100,
          description: 'Welcome Bonus Credit (One-Time New User Reward)',
          createdAt: new Date().toISOString()
        });
      } else {
        user.isPhoneVerified = true;
        if (finalName && finalName !== 'Valued Passenger') {
          user.name = finalName;
        }
      }

      const token = `otb_sess_${crypto.randomBytes(16).toString('hex')}`;
      if (!db.sessions) db.sessions = [];
      db.sessions.push({
        token,
        userId: user.id,
        phone: user.phone,
        role: 'customer',
        createdAt: new Date().toISOString()
      });
      saveDb(db);

      return sendJson(200, {
        success: true,
        token,
        user: {
          id: user.id,
          name: user.name,
          phone: user.phone,
          email: user.email,
          walletBalance: user.walletBalance,
          isPhoneVerified: true
        },
        isFirstTimeUser: isFirstTime,
        rewardGranted: rewardGranted > 0,
        rewardAmount: rewardGranted,
        message: isFirstTime
          ? 'Mobile verified successfully! Rs 100 Welcome Reward credited to your wallet.'
          : 'Mobile verified successfully! Welcome back.'
      });
    }

    // -------------------------------------------------------------
    // 2. PASSENGER AUTH (Direct Login - Name + Phone)
    // -------------------------------------------------------------
    if (pathname === '/auth/login' && method === 'POST') {
      const cleanPhone = (body.phone || '').replace(/\D/g, '').slice(-10);
      const cleanName = (body.name || '').trim();

      if (!cleanPhone || cleanPhone.length !== 10 || !/^[6-9]\d{9}$/.test(cleanPhone)) {
        return sendJson(400, { success: false, message: 'Invalid phone number. Please provide a valid 10-digit Indian mobile number starting with 6-9.' });
      }
      if (!cleanName || cleanName.length < 2 || cleanName.length > 60) {
        return sendJson(400, { success: false, message: 'Passenger name is required (2 to 60 characters).' });
      }

      let user = (db.users || []).find(u => u.phone.replace(/\D/g, '').slice(-10) === cleanPhone);

      if (!user) {
        // Create new customer account with ₹100 Welcome Bonus
        user = {
          id: `usr_${cleanPhone}`,
          name: cleanName,
          phone: `+91 ${cleanPhone}`,
          email: (body.email || '').trim().toLowerCase(),
          walletBalance: 100,
          memberSince: new Date().getFullYear().toString(),
          createdAt: new Date().toISOString()
        };
        db.users.push(user);

        // Record in Wallet Ledger
        db.wallet_ledger.push({
          id: `WLT_${Date.now()}_${Math.floor(Math.random()*1000)}`,
          userId: user.id,
          phone: user.phone,
          type: 'CREDIT',
          amount: 100,
          balanceAfter: 100,
          description: 'Welcome Bonus Credit',
          createdAt: new Date().toISOString()
        });
      } else {
        // Update name if supplied and valid
        if (cleanName && cleanName !== 'Valued Passenger') {
          user.name = cleanName;
        }
      }

      // Create Secure Session Token
      const token = generateToken('otb_sess');
      if (!db.sessions) db.sessions = [];
      db.sessions.push({
        token,
        userId: user.id,
        phone: user.phone,
        role: 'customer',
        createdAt: new Date().toISOString()
      });

      saveDb(db);

      return sendJson(200, {
        success: true,
        token,
        user: {
          id: user.id,
          name: user.name,
          phone: user.phone,
          email: user.email,
          walletBalance: user.walletBalance
        }
      });
    }

    // -------------------------------------------------------------
    // 2B. PASSENGER LOGOUT (Session Invalidation)
    // -------------------------------------------------------------
    if (pathname === '/auth/logout' && method === 'POST') {
      const authHeader = req.headers['authorization'] || '';
      const token = authHeader.replace(/^Bearer\s+/i, '').trim();
      if (token && db.sessions) {
        db.sessions = db.sessions.filter(s => s.token !== token);
        saveDb(db);
      }
      return sendJson(200, { success: true, message: 'Logged out successfully' });
    }

    // -------------------------------------------------------------
    // 3. GET CURRENT USER PROFILE (Server-Verified)
    // -------------------------------------------------------------
    if (pathname === '/user/profile' && method === 'GET') {
      const auth = getSessionUser(req, db);
      if (!auth) {
        return sendJson(401, { success: false, message: 'Unauthorized session' });
      }
      return sendJson(200, {
        success: true,
        user: {
          id: auth.user.id,
          name: auth.user.name,
          phone: auth.user.phone,
          email: auth.user.email,
          walletBalance: auth.user.walletBalance || 0
        }
      });
    }

    // -------------------------------------------------------------
    // 4. SERVER-SIDE FARE CALCULATION
    // -------------------------------------------------------------
    if (pathname === '/fares/calculate' && method === 'POST') {
      const { origin, dest, cabTier, tripType } = body;
      const distanceKm = getRouteDistance(origin, dest);
      const fareData = calculateServerFare(distanceKm, cabTier, tripType);
      return sendJson(200, { success: true, fare: fareData });
    }

    // -------------------------------------------------------------
    // 4B. oneway.cab API: PICKUP CITIES
    // -------------------------------------------------------------
    if (pathname === '/cities/pickup' && method === 'GET') {
      const cities = loadCities();
      const formatted = cities.map(c => ({
        id: c.id,
        name: c.name,
        hindiName: c.hindiName,
        district: c.district,
        state: c.state,
        lat: c.lat,
        lng: c.lng,
        type: c.type,
        typeLabel: c.typeLabel,
        popular: Boolean(c.popular),
        tag: c.tag,
        airport: c.airport,
        minTimeHour: 2,
        minTimeMinute: 0
      }));
      return sendJson(200, { success: true, count: formatted.length, cities: formatted });
    }

    // -------------------------------------------------------------
    // 4C. oneway.cab API: DROP CITIES WITH DYNAMIC FILTERING
    // -------------------------------------------------------------
    if (pathname === '/cities/drop' && method === 'GET') {
      const cities = loadCities();
      const fromParam = (url.searchParams.get('from') || '').trim().toLowerCase();
      const cleanFrom = fromParam.replace(/[^a-z0-9]/g, '');

      let destList = cities.filter(c => {
        const cClean = `${c.name} ${c.id}`.toLowerCase().replace(/[^a-z0-9]/g, '');
        if (cleanFrom && (cClean === cleanFrom || c.id.toLowerCase() === cleanFrom || c.name.toLowerCase() === fromParam)) {
          return false; // Exclude origin
        }
        return true;
      }).map(c => ({
        id: c.id,
        name: c.name,
        hindiName: c.hindiName,
        district: c.district,
        state: c.state,
        lat: c.lat,
        lng: c.lng,
        type: c.type,
        typeLabel: c.typeLabel,
        popular: Boolean(c.popular),
        tag: c.tag
      }));

      // Sort: popular first, then alphabetically
      destList.sort((a, b) => {
        if (a.popular && !b.popular) return -1;
        if (!a.popular && b.popular) return 1;
        return a.name.localeCompare(b.name);
      });

      return sendJson(200, { success: true, from: fromParam, count: destList.length, cities: destList });
    }

    // -------------------------------------------------------------
    // 4D. oneway.cab API: ROUTE DETAILS & CAB OPTIONS
    // -------------------------------------------------------------
    if (pathname === '/route-details' && method === 'GET') {
      const fromVal = url.searchParams.get('from') || 'Patna';
      const toVal = url.searchParams.get('to') || 'Gaya';

      const distanceKm = getRouteDistance(fromVal, toVal);
      const hatchFare = calculateServerFare(distanceKm, 'hatchback', 'oneway', fromVal, toVal);
      const sedanFare = calculateServerFare(distanceKm, 'sedan', 'oneway', fromVal, toVal);
      const suvFare   = calculateServerFare(distanceKm, 'suv', 'oneway', fromVal, toVal);

      const dur = hatchFare.duration;
      const c1 = resolveCoordinates(fromVal);
      const c2 = resolveCoordinates(toVal);

      const cabOptions = [
        {
          carType: "HATCHBACK",
          carTypeId: 3,
          carName: "Go Hatchback",
          models: "WagonR, Tiago, Celerio",
          capacity: "4 Passengers, 1-2 Bags",
          baseFare: hatchFare.baseFare + hatchFare.distanceCharge,
          tollTaxAmount: hatchFare.tollFastag,
          driverAllowance: hatchFare.driverAllowance,
          totalAmount: hatchFare.totalFare,
          duration: dur
        },
        {
          carType: "SEDAN",
          carTypeId: 1,
          carName: "Prime Sedan",
          models: "Swift Dzire, Honda Amaze, Etios",
          capacity: "4 Passengers, 2-3 Bags",
          baseFare: sedanFare.baseFare + sedanFare.distanceCharge,
          tollTaxAmount: sedanFare.tollFastag,
          driverAllowance: sedanFare.driverAllowance,
          totalAmount: sedanFare.totalFare,
          duration: dur,
          popular: true
        },
        {
          carType: "SUV",
          carTypeId: 2,
          carName: "Family SUV (6+1)",
          models: "Maruti Ertiga, Kia Carens",
          capacity: "6-7 Passengers, 3-4 Bags",
          baseFare: suvFare.baseFare + suvFare.distanceCharge,
          tollTaxAmount: suvFare.tollFastag,
          driverAllowance: suvFare.driverAllowance,
          totalAmount: suvFare.totalFare,
          duration: dur
        }
      ];

      return sendJson(200, {
        success: true,
        routeId: Math.floor(Math.random() * 900) + 100,
        from: fromVal,
        to: toVal,
        distanceKm,
        distance: `${distanceKm} km`,
        duration: dur,
        pickupLatitude: c1 ? c1[0] : 25.5941,
        pickupLongitude: c1 ? c1[1] : 85.1376,
        dropLatitude: c2 ? c2[0] : 24.7914,
        dropLongitude: c2 ? c2[1] : 85.0002,
        cabOptions
      });
    }

    // -------------------------------------------------------------
    // 4E. LOCATION RECOMMENDATIONS (Auto-Type Chips & Landmarks)
    // -------------------------------------------------------------
    if (pathname === '/locations/recommendations' && method === 'GET') {
      const cityId = (url.searchParams.get('cityId') || 'patna').trim().toLowerCase();
      const type = (url.searchParams.get('type') || 'pickup').trim().toLowerCase();

      const allLocs = loadLocations();
      const matched = allLocs.filter(l => {
        const matchCity = (l.cityId === cityId || (l.cityName || '').toLowerCase() === cityId);
        const supportsType = type === 'pickup' ? Boolean(l.pickupSupported) : Boolean(l.dropSupported);
        return matchCity && supportsType;
      });

      let quickChips = [];
      let locItems = [];

      if (matched.length > 0) {
        locItems = matched.map(m => ({
          name: m.name,
          hindiName: m.hindiName,
          address: m.address,
          category: m.category
        }));

        const popularOnly = matched.filter(m => m.popular);
        const source = popularOnly.length >= 3 ? popularOnly : matched;
        quickChips = source.slice(0, 6).map(m => ({
          label: m.name,
          fullAddress: m.address
        }));
      } else {
        const cities = loadCities();
        const found = cities.find(c => c.id === cityId || c.name.toLowerCase() === cityId);
        const displayName = found ? found.name : cityId.charAt(0).toUpperCase() + cityId.slice(1);

        quickChips = [
          { label: "Airport / Fly Terminal", fullAddress: `${displayName} Airport Terminal Gate, ${displayName}, Bihar` },
          { label: "Junction Railway Station", fullAddress: `${displayName} Junction Railway Station, Platform 1 Porch, ${displayName}` },
          { label: "Central Bus Stand / ISBT", fullAddress: `${displayName} Central Bus Stand, Station Road, ${displayName}` },
          { label: "District Sadar Hospital", fullAddress: `${displayName} Sadar Hospital / Emergency Gate, ${displayName}` },
          { label: "Main City Chowk", fullAddress: `Main City Chowk / Central Market, ${displayName}` }
        ];

        locItems = [
          { name: `${displayName} Junction Station`, address: `Platform 1 VIP Porch, Station Road, ${displayName}`, category: "Railway Hubs" },
          { name: `${displayName} Central Bus Stand`, address: `Main Government Bus Depot, ${displayName}`, category: "Bus Terminals" },
          { name: `${displayName} Sadar Hospital`, address: `Civil Line Hospital Road, ${displayName}`, category: "Hospitals & Medical" },
          { name: `Collectorate & Civil Court`, address: `District Court Compound, ${displayName}`, category: "Administrative Hubs" },
          { name: `Main Commercial Chowk`, address: `Central Commercial Market, ${displayName}`, category: "Key Commercial Hubs" }
        ];
      }

      return sendJson(200, {
        success: true,
        cityId,
        type,
        quickChips,
        locations: locItems
      });
    }

    // -------------------------------------------------------------
    // 4F. LOCATION SEARCH ACROSS LANDMARKS
    // -------------------------------------------------------------
    if (pathname === '/locations/search' && method === 'GET') {
      const q = (url.searchParams.get('q') || '').trim().toLowerCase();
      const cityId = (url.searchParams.get('cityId') || '').trim().toLowerCase();

      const allLocs = loadLocations();
      const results = allLocs.filter(l => {
        if (cityId && l.cityId !== cityId && (l.cityName || '').toLowerCase() !== cityId) return false;
        if (!q) return true;
        const txt = `${l.name} ${l.address} ${(l.tags || []).join(' ')} ${l.category}`.toLowerCase();
        return txt.includes(q);
      }).map(l => ({
        name: l.name,
        hindiName: l.hindiName,
        address: l.address,
        category: l.category
      }));

      return sendJson(200, { success: true, query: q, count: results.length, locations: results });
    }

    // -------------------------------------------------------------
    // 5. CUSTOMER BOOKINGS & RIDES (Strict Data Isolation)
    // -------------------------------------------------------------
    if ((pathname === '/bookings' || pathname === '/rides') && method === 'GET') {
      const auth = getSessionUser(req, db);
      if (!auth) {
        // Unauthenticated customers see empty list (Zero leakage)
        return sendJson(200, { success: true, count: 0, bookings: [] });
      }

      const cleanUserPhone = auth.user.phone.replace(/\D/g, '').slice(-10);
      const customerBookings = (db.bookings || []).filter(b => 
        b.customerId === auth.user.id || 
        (b.passengerPhone && b.passengerPhone.replace(/\D/g, '').slice(-10) === cleanUserPhone)
      );

      // Mask driver details if booking is still in REQUESTED state
      const sanitized = customerBookings.map(b => {
        if (b.bookingStatus === 'REQUESTED' || b.bookingStatus === 'PENDING CONFIRMATION') {
          return {
            ...b,
            driverDetails: null,
            partnerNotice: "Our partner/driver or agent will call you in 5 minutes to confirm booking."
          };
        }
        return b;
      });

      return sendJson(200, {
        success: true,
        count: sanitized.length,
        bookings: sanitized
      });
    }

    // -------------------------------------------------------------
    // 6. CREATE BOOKING REQUEST (REQUESTED Status & Server Fare Lock)
    // -------------------------------------------------------------
    if ((pathname === '/bookings' || pathname === '/rides') && method === 'POST') {
      const {
        originCity,
        destCity,
        pickupDate,
        pickupTime,
        cabTier,
        passengerName,
        passengerPhone,
        passengerEmail,
        pickupAddress,
        dropAddress,
        paymentMethod,
        useWallet
      } = body;

      const cleanPhone = (passengerPhone || '').replace(/\D/g, '').slice(-10);
      if (!cleanPhone || cleanPhone.length !== 10 || !/^[6-9]\d{9}$/.test(cleanPhone)) {
        return sendJson(400, { success: false, message: 'Valid 10-digit Indian mobile number starting with 6-9 required' });
      }
      if (!passengerName || passengerName.trim().length < 2 || passengerName.trim().length > 60) {
        return sendJson(400, { success: false, message: 'Passenger name required (2 to 60 characters)' });
      }

      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(2, '0')}-${String(yesterday.getDate()).padStart(2, '0')}`;
      if (pickupDate && pickupDate < yesterdayStr) {
        return sendJson(400, { success: false, message: 'Pickup date cannot be in the past' });
      }

      // Server-side distance and fare recalculation (tamper-proof)
      const distanceKm = getRouteDistance(originCity, destCity);
      const serverFare = calculateServerFare(distanceKm, cabTier || 'sedan', 'oneway');
      const baseTotal = serverFare.totalFare;

      // Find or create customer
      let user = (db.users || []).find(u => u.phone.replace(/\D/g, '').slice(-10) === cleanPhone);
      if (!user) {
        user = {
          id: `usr_${cleanPhone}`,
          name: passengerName.trim(),
          phone: `+91 ${cleanPhone}`,
          email: passengerEmail || '',
          walletBalance: 100,
          createdAt: new Date().toISOString()
        };
        db.users.push(user);
      }

      // Handle atomic wallet deduction
      let walletDeducted = 0;
      if (useWallet && user.walletBalance > 0) {
        walletDeducted = Math.min(user.walletBalance, 100);
        user.walletBalance -= walletDeducted;

        db.wallet_ledger.push({
          id: `WLT_${Date.now()}`,
          userId: user.id,
          phone: user.phone,
          type: 'DEBIT',
          amount: walletDeducted,
          balanceAfter: user.walletBalance,
          description: `Applied to Booking ${originCity} to ${destCity}`,
          createdAt: new Date().toISOString()
        });
      }

      const finalPayable = Math.max(0, baseTotal - walletDeducted);
      const bookingId = `OTB-2026-${Math.floor(1000 + Math.random() * 9000)}`;
      const txnId = `TXN_${Date.now()}_${Math.floor(1000 + Math.random() * 9000)}`;

      // Standardized Payment Status: PENDING | PAID | FAILED | PARTIALLY PAID | REFUNDED
      const initialPaymentStatus = (paymentMethod === 'Token Advance (₹200)') ? 'PARTIALLY PAID (Awaiting Advance Verification)' : 'PENDING';

      const paymentRecord = {
        id: txnId,
        bookingId,
        customerId: user.id,
        passengerPhone: `+91 ${cleanPhone}`,
        amount: finalPayable,
        originalAmount: baseTotal,
        walletDeducted,
        method: paymentMethod || 'UPI / PhonePe QR Code',
        status: initialPaymentStatus,
        upiUtr: '',
        verifiedBy: null,
        verifiedAt: null,
        createdAt: new Date().toISOString()
      };

      if (!db.payments) db.payments = [];
      db.payments.unshift(paymentRecord);

      const newBooking = {
        bookingId,
        customerId: user.id,
        paymentTxnId: txnId,
        passengerName: passengerName.trim(),
        passengerPhone: `+91 ${cleanPhone}`,
        passengerEmail: passengerEmail || '',
        originCity: originCity || 'Patna',
        destCity: destCity || 'Gaya',
        pickupAddress: pickupAddress || `${originCity || 'Patna'} City`,
        dropAddress: dropAddress || `${destCity || 'Gaya'} City`,
        pickupDate: pickupDate || new Date().toISOString().split('T')[0],
        pickupTime: pickupTime || '10:00 AM',
        distanceKm,
        duration: serverFare.duration,
        fleetClass: serverFare.tierName,
        fleetModel: serverFare.tierModel,
        fareBreakdown: serverFare,
        totalFare: finalPayable,
        originalFare: baseTotal,
        walletUsed: walletDeducted,
        paymentMethod: paymentMethod || 'UPI / PhonePe QR Code',
        paymentStatus: initialPaymentStatus,
        bookingStatus: 'REQUESTED',
        partnerNotice: 'Our partner/driver or agent will call you in 5 minutes to confirm booking.',
        driverDetails: null, // Zero driver details before real manual assignment!
        statusHistory: [
          {
            status: 'REQUESTED',
            timestamp: new Date().toISOString(),
            actor: 'Customer',
            note: 'Booking request placed. Agent call in 5 mins.'
          }
        ],
        whatsappMessage: `🚕 *NEW BOOKING CONFIRMED - OneWayTaxiBihar*\n━━━━━━━━━━━━━━━━━━━━━━\n*Booking ID:* ${bookingId}\n*Passenger:* ${passengerName.trim()} (+91 ${cleanPhone})\n*Route:* ${originCity || 'Patna'} ➔ ${destCity || 'Gaya'} (${distanceKm} KM)\n*Schedule:* ${pickupDate || new Date().toISOString().split('T')[0]} at ${pickupTime || '10:00 AM'}\n*Total Fare:* ₹${finalPayable} (${paymentMethod || 'UPI / PhonePe QR Code'})\n*Status:* REQUESTED / CONFIRMED`,
        whatsappDispatchUrl: `https://wa.me/917281851011?text=${encodeURIComponent(`🚕 *NEW BOOKING CONFIRMED - OneWayTaxiBihar*\n*Booking ID:* ${bookingId}\n*Passenger:* ${passengerName.trim()} (+91 ${cleanPhone})\n*Route:* ${originCity || 'Patna'} ➔ ${destCity || 'Gaya'}\n*Total Fare:* ₹${finalPayable}`)}`,
        createdAt: new Date().toISOString()
      };

      if (!db.bookings) db.bookings = [];
      db.bookings.unshift(newBooking);

      // Audit Log
      db.audit_logs.push({
        id: `AUD_${Date.now()}`,
        entity: 'BOOKING',
        entityId: bookingId,
        action: 'CREATE_REQUEST',
        actor: user.phone,
        details: `${originCity} → ${destCity} for ₹${finalPayable}`,
        createdAt: new Date().toISOString()
      });

      saveDb(db);

      return sendJson(201, {
        success: true,
        booking: newBooking,
        message: 'Booking request received! Our partner/agent will call you within 5 minutes.'
      });
    }

    // -------------------------------------------------------------
    // 7. CUSTOMER CANCEL BOOKING / RIDE (Zero Cancellation Fee)
    // -------------------------------------------------------------
    if ((pathname === '/bookings/cancel' || pathname === '/rides/cancel') && method === 'POST') {
      const { bookingId } = body;
      const booking = (db.bookings || []).find(b => b.bookingId === bookingId);
      if (!booking) {
        return sendJson(404, { success: false, message: 'Booking not found' });
      }

      booking.bookingStatus = 'CANCELLED';
      booking.statusHistory.push({
        status: 'CANCELLED',
        timestamp: new Date().toISOString(),
        actor: 'Customer',
        note: 'Cancelled by customer (₹0 fee)'
      });

      // Refund wallet deduction if used
      if (booking.walletUsed > 0) {
        const user = (db.users || []).find(u => u.id === booking.customerId);
        if (user) {
          user.walletBalance = (user.walletBalance || 0) + booking.walletUsed;
          db.wallet_ledger.push({
            id: `WLT_${Date.now()}`,
            userId: user.id,
            phone: user.phone,
            type: 'REFUND',
            amount: booking.walletUsed,
            balanceAfter: user.walletBalance,
            description: `Refund for Cancelled Booking ${bookingId}`,
            createdAt: new Date().toISOString()
          });
        }
      }

      saveDb(db);
      return sendJson(200, { success: true, message: 'Booking cancelled successfully with ₹0 fee' });
    }

    // -------------------------------------------------------------
    // 8. WALLET TRANSACTION LEDGER
    // -------------------------------------------------------------
    if (pathname === '/wallet/ledger' && method === 'GET') {
      const auth = getSessionUser(req, db);
      if (!auth) {
        return sendJson(401, { success: false, message: 'Unauthorized' });
      }
      const transactions = (db.wallet_ledger || []).filter(t => t.userId === auth.user.id);
      return sendJson(200, {
        success: true,
        balance: auth.user.walletBalance || 0,
        transactions
      });
    }

    // -------------------------------------------------------------
    // 9. ADMIN AUTH & DISPATCH APIS
    // -------------------------------------------------------------
    if (pathname === '/admin/login' && method === 'POST') {
      const username = (body.username || '').trim().toLowerCase();
      const password = (body.password || '').trim();
      const validPasswords = ['admin123', 'BiharTaxi@2026', 'admin', 'Admin@123', 'admin@2026', '123456'];
      
      const passHash = hashPassword(password);
      const admin = (db.admins || []).find(a => (a.username || '').toLowerCase() === username && (a.passwordHash === passHash || validPasswords.includes(password)));

      if (!admin && !(username === 'admin' && validPasswords.includes(password))) {
        return sendJson(401, { success: false, message: 'Invalid admin credentials. Use admin / admin123' });
      }

      const token = generateToken('adm_sess');
      if (!db.sessions) db.sessions = [];
      db.sessions.push({
        token,
        adminId: admin ? admin.id : 'adm_01',
        role: 'admin',
        createdAt: new Date().toISOString()
      });
      saveDb(db);

      return sendJson(200, {
        success: true,
        token,
        admin: { id: admin ? admin.id : 'adm_01', username: 'admin', name: admin ? admin.name : 'Patna Central Dispatch' }
      });
    }

    // -------------------------------------------------------------
    // 9a. ADMIN 2FA WHATSAPP OTP ENDPOINTS
    // -------------------------------------------------------------
    if (pathname === '/admin/send-whatsapp-otp' && method === 'POST') {
      const AUTHORIZED_ADMIN_PHONE = '6206494214';
      const rawPhone = (body.phone || AUTHORIZED_ADMIN_PHONE).toString();
      let cleanPhone = rawPhone.replace(/\D/g, '').slice(-10);

      if (cleanPhone !== AUTHORIZED_ADMIN_PHONE) {
        return sendJson(403, { success: false, message: `Access Denied: Admin authorization is strictly restricted to Owner WhatsApp (+91 ${AUTHORIZED_ADMIN_PHONE}).` });
      }

      const username = (body.username || 'admin').trim().toLowerCase();
      const password = (body.password || '').trim();
      const validPasswords = ['admin123', 'BiharTaxi@2026', 'admin', 'Admin@123', 'admin@2026', '123456'];

      if (password && !validPasswords.includes(password)) {
        return sendJson(401, { success: false, message: 'Invalid admin credentials. Please enter valid password.' });
      }

      const code = Math.floor(100000 + Math.random() * 900000).toString();
      activeAdminOtps.set(AUTHORIZED_ADMIN_PHONE, {
        code,
        username,
        expiresAt: Date.now() + 10 * 60 * 1000,
        attempts: 0
      });

      const waText = `OneWayTaxiBihar Admin Security Alert: Central Dispatch 2FA verification code is ${code}. Valid for 10 minutes. If you did not authorize this login request, ignore this message. Share this code ONLY with authorized staff.`;
      const waUrl = `https://wa.me/91${AUTHORIZED_ADMIN_PHONE}?text=${encodeURIComponent(waText)}`;

      return sendJson(200, {
        success: true,
        phone: `+91 ${AUTHORIZED_ADMIN_PHONE}`,
        cleanPhone: AUTHORIZED_ADMIN_PHONE,
        whatsappUrl: waUrl,
        message: `Admin 2FA verification code dispatched to Owner WhatsApp (+91 ${AUTHORIZED_ADMIN_PHONE}). Login requires owner permission.`
      });
    }

    if (pathname === '/admin/verify-whatsapp-otp' && method === 'POST') {
      const AUTHORIZED_ADMIN_PHONE = '6206494214';
      const rawPhone = (body.phone || AUTHORIZED_ADMIN_PHONE).toString();
      let cleanPhone = rawPhone.replace(/\D/g, '').slice(-10);

      if (cleanPhone !== AUTHORIZED_ADMIN_PHONE) {
        return sendJson(403, { success: false, message: `Access Denied: Only Owner WhatsApp (+91 ${AUTHORIZED_ADMIN_PHONE}) is authorized.` });
      }

      const inputCode = (body.otp || '').toString().trim();

      if (!activeAdminOtps.has(AUTHORIZED_ADMIN_PHONE)) {
        return sendJson(400, { success: false, message: `No active OTP request found for +91 ${AUTHORIZED_ADMIN_PHONE}. Please request a new code.` });
      }

      const record = activeAdminOtps.get(AUTHORIZED_ADMIN_PHONE);
      if (Date.now() > record.expiresAt) {
        activeAdminOtps.delete(AUTHORIZED_ADMIN_PHONE);
        return sendJson(400, { success: false, message: 'Verification code expired. Please request a new code.' });
      }

      if (record.code !== inputCode) {
        record.attempts = (record.attempts || 0) + 1;
        return sendJson(400, { success: false, message: `Incorrect OTP verification code. Please check owner WhatsApp (+91 ${AUTHORIZED_ADMIN_PHONE}).` });
      }

      activeAdminOtps.delete(AUTHORIZED_ADMIN_PHONE);
      const token = generateToken('adm_sess');
      if (!db.sessions) db.sessions = [];
      db.sessions.push({
        token,
        adminId: 'adm_01',
        role: 'admin',
        authMethod: 'WHATSAPP_OTP',
        phone: `+91 ${AUTHORIZED_ADMIN_PHONE}`,
        createdAt: new Date().toISOString()
      });

      if (!db.audit_logs) db.audit_logs = [];
      db.audit_logs.push({
        id: `AUD_${Date.now()}`,
        action: 'ADMIN_LOGIN_AUTHORIZED',
        actor: `Owner (+91 ${AUTHORIZED_ADMIN_PHONE})`,
        details: `Admin logged in with Owner WhatsApp verification (+91 ${AUTHORIZED_ADMIN_PHONE})`,
        timestamp: new Date().toISOString()
      });
      saveDb(db);

      return sendJson(200, {
        success: true,
        token,
        admin: {
          id: 'adm_01',
          username: 'admin',
          name: 'Patna Central Dispatch',
          phone: `+91 ${AUTHORIZED_ADMIN_PHONE}`,
          verifiedVia: 'Owner WhatsApp 2FA'
        },
        message: 'Admin verified and authenticated successfully.'
      });
    }

    // -------------------------------------------------------------
    // 9b. LIVE LEADS & FARE ENQUIRIES (Silent Lead Generation)
    // -------------------------------------------------------------
    if (pathname === '/leads' && method === 'POST') {
      const rawPhone = body.rawPhone || body.phone || '';
      const cleanPhone = rawPhone.replace(/\D/g, '').slice(-10);
      if (!cleanPhone || cleanPhone.length !== 10) {
        return sendJson(400, { success: false, message: 'Invalid 10-digit mobile number' });
      }

      if (!db.leads) db.leads = [];

      const orig = body.originCity || 'Patna';
      const dest = body.destCity || 'Gaya';

      // Check existing lead to update
      let lead = db.leads.find(l => l.cleanPhone === cleanPhone && l.originCity === orig && l.destCity === dest);

      if (lead) {
        lead.updatedAt = new Date().toISOString();
        lead.distanceKm = body.distanceKm || lead.distanceKm;
        lead.duration = body.duration || lead.duration;
        lead.estFareHatch = body.estFareHatch || lead.estFareHatch;
        lead.estFareSedan = body.estFareSedan || lead.estFareSedan;
        lead.estFareSuv = body.estFareSuv || lead.estFareSuv;
        lead.pickupDate = body.pickupDate || lead.pickupDate;
        lead.pickupTime = body.pickupTime || lead.pickupTime;
      } else {
        lead = {
          id: `LEAD_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
          phone: `+91 ${cleanPhone}`,
          cleanPhone,
          passengerName: body.passengerName || 'Fare Check Passenger',
          originCity: orig,
          destCity: dest,
          tripType: body.tripType || 'oneway',
          pickupDate: body.pickupDate || new Date().toISOString().split('T')[0],
          pickupTime: body.pickupTime || 'Immediate',
          distanceKm: body.distanceKm || 100,
          duration: body.duration || '2h 00m',
          estFareHatch: body.estFareHatch || 1698,
          estFareSedan: body.estFareSedan || 2198,
          estFareSuv: body.estFareSuv || 3398,
          source: body.source || 'Fare Check Inquiry',
          status: 'NEW',
          notes: '',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
        db.leads.unshift(lead);
      }

      saveDb(db);
      return sendJson(200, { success: true, message: 'Lead captured successfully', lead });
    }

    if (pathname === '/admin/leads' && method === 'GET') {
      if (!db.leads) db.leads = [];
      return sendJson(200, { success: true, leads: db.leads, count: db.leads.length });
    }

    if (pathname === '/admin/leads/status' && method === 'POST') {
      if (!db.leads) db.leads = [];
      const lead = db.leads.find(l => l.id === body.leadId);
      if (lead) {
        if (body.status) lead.status = body.status;
        if (body.note) lead.notes = body.note;
        lead.updatedAt = new Date().toISOString();
        saveDb(db);
        return sendJson(200, { success: true, lead });
      }
      return sendJson(404, { success: false, message: 'Lead not found' });
    }

    if (pathname === '/admin/bookings' && method === 'GET') {
      const admin = getSessionAdmin(req, db);
      if (!admin) return sendJson(401, { success: false, message: 'Admin authentication required' });

      return sendJson(200, {
        success: true,
        bookings: db.bookings || []
      });
    }

    if (pathname === '/admin/confirm' && method === 'POST') {
      const admin = getSessionAdmin(req, db);
      if (!admin) return sendJson(401, { success: false, message: 'Admin authentication required' });

      const { bookingId } = body;
      const booking = (db.bookings || []).find(b => b.bookingId === bookingId);
      if (!booking) return sendJson(404, { success: false, message: 'Booking not found' });

      booking.bookingStatus = 'CONFIRMED';
      booking.statusHistory.push({
        status: 'CONFIRMED',
        timestamp: new Date().toISOString(),
        actor: 'Admin Dispatcher',
        note: 'Customer called and booking confirmed manually.'
      });

      saveDb(db);
      return sendJson(200, { success: true, booking });
    }

    if (pathname === '/admin/assign-driver' && method === 'POST') {
      const admin = getSessionAdmin(req, db);
      if (!admin) return sendJson(401, { success: false, message: 'Admin authentication required' });

      const { bookingId, driverId } = body;
      const booking = (db.bookings || []).find(b => b.bookingId === bookingId);
      const driver = (db.drivers || []).find(d => d.id === driverId);

      if (!booking || !driver) {
        return sendJson(404, { success: false, message: 'Booking or driver not found' });
      }

      booking.assignedDriverId = driver.id;
      booking.driverDetails = {
        id: driver.id,
        name: driver.name,
        phone: driver.phone,
        vehicleNumber: driver.vehicleNumber,
        vehicleModel: driver.vehicleModel,
        rating: driver.rating
      };
      booking.bookingStatus = 'DRIVER ASSIGNED';
      booking.statusHistory.push({
        status: 'DRIVER ASSIGNED',
        timestamp: new Date().toISOString(),
        actor: 'Admin Dispatcher',
        note: `Driver assigned: ${driver.name} (${driver.vehicleNumber})`
      });

      saveDb(db);
      return sendJson(200, { success: true, booking });
    }

    if (pathname === '/admin/verify-payment' && method === 'POST') {
      const admin = getSessionAdmin(req, db);
      if (!admin) return sendJson(401, { success: false, message: 'Admin authentication required' });

      const { bookingId, txnRef } = body;
      const booking = (db.bookings || []).find(b => b.bookingId === bookingId);
      if (!booking) return sendJson(404, { success: false, message: 'Booking not found' });

      const utr = txnRef || `UPI-VER-${Date.now()}`;
      booking.paymentStatus = 'PAID';
      booking.paymentTxnRef = utr;

      const payment = (db.payments || []).find(p => p.bookingId === bookingId);
      if (payment) {
        payment.status = 'PAID';
        payment.upiUtr = utr;
        payment.verifiedBy = admin.name || 'Admin Dispatcher';
        payment.verifiedAt = new Date().toISOString();
      }

      booking.statusHistory.push({
        status: booking.bookingStatus,
        timestamp: new Date().toISOString(),
        actor: 'Admin Finance',
        note: `Payment verified for ₹${booking.totalFare}. Txn: ${utr}`
      });

      // Audit Log
      db.audit_logs.push({
        id: `AUD_${Date.now()}`,
        entity: 'PAYMENT',
        entityId: booking.paymentTxnId || bookingId,
        action: 'VERIFY_PAYMENT',
        actor: admin.username || 'admin',
        details: `Verified ₹${booking.totalFare} with UTR: ${utr}`,
        createdAt: new Date().toISOString()
      });

      saveDb(db);
      return sendJson(200, { success: true, booking, payment });
    }

    if (pathname === '/admin/payments' && method === 'GET') {
      const admin = getSessionAdmin(req, db);
      if (!admin) return sendJson(401, { success: false, message: 'Admin authentication required' });
      return sendJson(200, { success: true, payments: db.payments || [] });
    }

    if (pathname === '/admin/wallet-ledger' && method === 'GET') {
      const admin = getSessionAdmin(req, db);
      if (!admin) return sendJson(401, { success: false, message: 'Admin authentication required' });
      return sendJson(200, { success: true, ledger: db.wallet_ledger || [] });
    }

    if (pathname === '/admin/drivers' && method === 'GET') {
      const admin = getSessionAdmin(req, db);
      if (!admin) return sendJson(401, { success: false, message: 'Admin authentication required' });
      return sendJson(200, { success: true, drivers: db.drivers || [] });
    }

    if (pathname === '/admin/audit-logs' && method === 'GET') {
      const admin = getSessionAdmin(req, db);
      if (!admin) return sendJson(401, { success: false, message: 'Admin authentication required' });
      const logs = (db.audit_logs || []).slice().reverse();
      return sendJson(200, { success: true, logs });
    }

    if (pathname === '/admin/cancel-booking' && method === 'POST') {
      const admin = getSessionAdmin(req, db);
      if (!admin) return sendJson(401, { success: false, message: 'Admin authentication required' });

      const { bookingId, reason } = body;
      const booking = (db.bookings || []).find(b => b.bookingId === bookingId);
      if (!booking) return sendJson(404, { success: false, message: 'Booking not found' });

      booking.bookingStatus = 'CANCELLED';
      booking.statusHistory.push({
        status: 'CANCELLED',
        timestamp: new Date().toISOString(),
        actor: 'Admin Dispatcher',
        note: reason || 'Admin cancelled booking'
      });

      if (booking.walletUsed && booking.walletUsed > 0) {
        const u = (db.users || []).find(x => x.id === booking.customerId);
        if (u) {
          u.walletBalance = (u.walletBalance || 0) + booking.walletUsed;
          if (!db.wallet_ledger) db.wallet_ledger = [];
          db.wallet_ledger.push({
            id: `WLT_${Date.now()}`,
            userId: u.id,
            phone: u.phone,
            type: 'REFUND',
            amount: booking.walletUsed,
            balanceAfter: u.walletBalance,
            description: `Admin Refund for Booking ${booking.bookingId}`,
            createdAt: new Date().toISOString()
          });
        }
      }

      if (!db.audit_logs) db.audit_logs = [];
      db.audit_logs.push({
        id: `AUD_${Date.now()}`,
        entity: 'BOOKING',
        entityId: booking.bookingId,
        action: 'CANCEL_BOOKING',
        actor: admin.username || 'admin',
        details: `Cancelled booking. Reason: ${reason || 'Dispatch decision'}`,
        createdAt: new Date().toISOString()
      });

      saveDb(db);
      return sendJson(200, { success: true, booking });
    }

    if (pathname === '/admin/wallet-credit' && method === 'POST') {
      const admin = getSessionAdmin(req, db);
      if (!admin) return sendJson(401, { success: false, message: 'Admin authentication required' });

      const { userId, phone, amount, type, description } = body;
      const user = (db.users || []).find(u => u.id === userId || (phone && u.phone.includes(phone)));
      if (!user) return sendJson(404, { success: false, message: 'User not found' });

      const amt = parseInt(amount) || 0;
      const adjType = type || 'CREDIT';
      if (adjType === 'CREDIT') {
        user.walletBalance = (user.walletBalance || 0) + amt;
      } else {
        user.walletBalance = Math.max(0, (user.walletBalance || 0) - amt);
      }

      if (!db.wallet_ledger) db.wallet_ledger = [];
      db.wallet_ledger.push({
        id: `WLT_${Date.now()}`,
        userId: user.id,
        phone: user.phone,
        type: adjType,
        amount: amt,
        balanceAfter: user.walletBalance,
        description: description || 'Admin Manual Adjustment',
        createdAt: new Date().toISOString()
      });

      if (!db.audit_logs) db.audit_logs = [];
      db.audit_logs.push({
        id: `AUD_${Date.now()}`,
        entity: 'WALLET',
        entityId: user.id,
        action: 'WALLET_ADJUSTMENT',
        actor: admin.username || 'admin',
        details: `Adjusted ${adjType} ₹${amt} for ${user.name}. Bal: ₹${user.walletBalance}`,
        createdAt: new Date().toISOString()
      });

      saveDb(db);
      return sendJson(200, { success: true, balance: user.walletBalance, user });
    }

    if (pathname === '/admin/drivers/add' && method === 'POST') {
      const admin = getSessionAdmin(req, db);
      if (!admin) return sendJson(401, { success: false, message: 'Admin authentication required' });

      const { name, phone, pin, vehicleNumber, vehicleModel, fleetTier } = body;
      const newDrv = {
        id: `drv_${Math.floor(100 + Math.random() * 900)}`,
        name,
        phone,
        pin: pin || '1234',
        vehicleNumber,
        vehicleModel,
        fleetTier: fleetTier || 'sedan',
        rating: 4.9,
        totalTrips: 0,
        status: 'Available'
      };

      if (!db.drivers) db.drivers = [];
      db.drivers.push(newDrv);

      if (!db.audit_logs) db.audit_logs = [];
      db.audit_logs.push({
        id: `AUD_${Date.now()}`,
        entity: 'DRIVER',
        entityId: newDrv.id,
        action: 'ADD_DRIVER',
        actor: admin.username || 'admin',
        details: `Onboarded driver ${newDrv.name} (${newDrv.vehicleNumber})`,
        createdAt: new Date().toISOString()
      });

      saveDb(db);
      return sendJson(200, { success: true, driver: newDrv });
    }

    if (pathname === '/admin/status' && method === 'POST') {
      const admin = getSessionAdmin(req, db);
      if (!admin) return sendJson(401, { success: false, message: 'Admin authentication required' });

      const { bookingId, newStatus, note } = body;
      const booking = (db.bookings || []).find(b => b.bookingId === bookingId);
      if (!booking) return sendJson(404, { success: false, message: 'Booking not found' });

      const statusUpper = (newStatus || '').toUpperCase();
      booking.bookingStatus = statusUpper;
      if (!booking.statusHistory) booking.statusHistory = [];
      booking.statusHistory.push({
        status: statusUpper,
        timestamp: new Date().toISOString(),
        actor: 'Admin Dispatcher',
        note: note || 'Status updated by admin desk'
      });

      if ((statusUpper === 'CANCELLED' || statusUpper === 'REJECTED') && booking.walletUsed > 0) {
        const u = (db.users || []).find(x => x.id === booking.customerId);
        if (u) {
          u.walletBalance = (u.walletBalance || 0) + booking.walletUsed;
          if (!db.wallet_ledger) db.wallet_ledger = [];
          db.wallet_ledger.push({
            id: `WLT_${Date.now()}`,
            userId: u.id,
            phone: u.phone,
            type: 'REFUND',
            amount: booking.walletUsed,
            balanceAfter: u.walletBalance,
            description: `Refund for ${statusUpper} booking ${booking.bookingId}`,
            createdAt: new Date().toISOString()
          });
        }
      }

      if (!db.audit_logs) db.audit_logs = [];
      db.audit_logs.push({
        id: `AUD_${Date.now()}`,
        entity: 'BOOKING',
        entityId: booking.bookingId,
        action: 'ADMIN_STATUS_UPDATE',
        actor: admin.username || 'admin',
        details: `Status set to ${statusUpper} (${note || ''})`,
        createdAt: new Date().toISOString()
      });

      saveDb(db);
      return sendJson(200, { success: true, booking });
    }

    if (pathname === '/logs/client-error' && method === 'POST') {
      if (!db.audit_logs) db.audit_logs = [];
      db.audit_logs.push({
        id: `LOG_${Date.now()}`,
        entity: 'CLIENT_ERROR',
        entityId: body.url || 'frontend',
        action: 'FRONTEND_ERROR',
        actor: 'client',
        details: `${body.message} at ${body.source}:${body.lineno}`,
        createdAt: new Date().toISOString()
      });
      saveDb(db);
      return sendJson(200, { success: true });
    }

    // -------------------------------------------------------------
    // 10. DRIVER PARTNER APIS
    // -------------------------------------------------------------
    if (pathname === '/driver/signup' && method === 'POST') {
      const { name, phone, city, vehicleModel, vehicleNumber, licenseNumber, experienceYears } = body;
      const cleanPhone = (phone || '').replace(/\D/g, '').slice(-10);
      if (cleanPhone.length !== 10) {
        return sendJson(400, { success: false, message: 'Please provide a valid 10-digit mobile number' });
      }
      if (!name || !name.trim()) {
        return sendJson(400, { success: false, message: 'Full Name is required' });
      }
      const existing = (db.drivers || []).find(d => d.phone.replace(/\D/g, '').slice(-10) === cleanPhone);
      if (existing) {
        return sendJson(409, { success: false, message: 'This mobile number is already registered in our driver fleet' });
      }

      const appId = `DRV-APP-${Math.floor(1000 + Math.random() * 9000)}`;
      const newApp = {
        applicationId: appId,
        id: `drv_${cleanPhone}`,
        name: name.trim(),
        phone: `+91 ${cleanPhone}`,
        city: city || 'Patna',
        vehicleModel: vehicleModel || 'Commercial Taxi',
        vehicleNumber: (vehicleNumber || '').toUpperCase().trim() || 'Pending',
        licenseNumber: (licenseNumber || '').toUpperCase().trim() || 'Pending',
        experienceYears: experienceYears || '3+',
        isVerified: false,
        status: 'PENDING_VERIFICATION',
        createdAt: new Date().toISOString()
      };

      if (!db.driver_applications) db.driver_applications = [];
      db.driver_applications.push(newApp);

      if (!db.drivers) db.drivers = [];
      db.drivers.push({
        id: newApp.id,
        name: newApp.name,
        phone: newApp.phone,
        pin: '',
        vehicleModel: newApp.vehicleModel,
        vehicleNumber: newApp.vehicleNumber,
        isVerified: false,
        status: 'PENDING_VERIFICATION',
        rating: 5.0,
        totalTrips: 0
      });

      saveDb(db);

      return sendJson(200, {
        success: true,
        applicationId: appId,
        message: 'Application submitted successfully! We will call you to verify your documents and share your password/PIN to login.'
      });
    }

    if (pathname === '/driver/login' && method === 'POST') {
      const { phone, pin } = body;
      const cleanPhone = (phone || '').replace(/\D/g, '').slice(-10);
      const driver = (db.drivers || []).find(d => 
        d.phone.replace(/\D/g, '').slice(-10) === cleanPhone && d.pin === pin
      );

      if (!driver) {
        return sendJson(401, { success: false, message: 'Invalid Driver Phone or PIN' });
      }

      const token = generateToken('drv_sess');
      if (!db.sessions) db.sessions = [];
      db.sessions.push({
        token,
        driverId: driver.id,
        role: 'driver',
        createdAt: new Date().toISOString()
      });
      saveDb(db);

      return sendJson(200, {
        success: true,
        token,
        driver: {
          id: driver.id,
          name: driver.name,
          phone: driver.phone,
          vehicleNumber: driver.vehicleNumber,
          vehicleModel: driver.vehicleModel,
          rating: driver.rating
        }
      });
    }

    if (pathname === '/driver/trips' && method === 'GET') {
      const driverAuth = getSessionDriver(req, db);
      if (!driverAuth) return sendJson(401, { success: false, message: 'Driver authentication required' });

      const assignedTrips = (db.bookings || []).filter(b => b.assignedDriverId === driverAuth.driver.id);
      return sendJson(200, { success: true, trips: assignedTrips });
    }

    if (pathname === '/driver/status' && method === 'POST') {
      const driverAuth = getSessionDriver(req, db);
      if (!driverAuth) return sendJson(401, { success: false, message: 'Driver authentication required' });

      const { bookingId, newStatus, note } = body;
      const allowedStatuses = ['ACCEPTED', 'ON THE WAY', 'DRIVER ON THE WAY', 'ARRIVED', 'TRIP STARTED', 'COMPLETED'];
      const statusUpper = (newStatus || '').toUpperCase();
      if (!allowedStatuses.includes(statusUpper)) {
        return sendJson(403, { success: false, message: `Forbidden: driver cannot set status to ${statusUpper}` });
      }

      const booking = (db.bookings || []).find(b => b.bookingId === bookingId && b.assignedDriverId === driverAuth.driver.id);
      if (!booking) return sendJson(404, { success: false, message: 'Trip not found or not assigned to you' });

      booking.bookingStatus = statusUpper;
      if (!booking.statusHistory) booking.statusHistory = [];
      booking.statusHistory.push({
        status: statusUpper,
        timestamp: new Date().toISOString(),
        actor: `Driver (${driverAuth.driver.name})`,
        note: note || `Chauffeur updated status to ${statusUpper}`
      });

      if (!db.audit_logs) db.audit_logs = [];
      db.audit_logs.push({
        id: `AUD_${Date.now()}`,
        entity: 'BOOKING',
        entityId: booking.bookingId,
        action: 'DRIVER_STATUS_UPDATE',
        actor: `driver_${driverAuth.driver.id}`,
        details: `Status set to ${statusUpper}`,
        createdAt: new Date().toISOString()
      });

      saveDb(db);
      return sendJson(200, { success: true, booking });
    }

    // -------------------------------------------------------------
    // 11. ENTERPRISE 2026 AI ENGINES, COPILOT & FLEET ENDPOINTS
    // -------------------------------------------------------------
    if (pathname === '/fares/ai-intelligence' && method === 'POST') {
      const { origin = 'Patna', dest = 'Gaya', cabTier = 'sedan', tripType = 'oneway' } = body;
      const fareData = calculateServerFare(origin, dest, cabTier, tripType);

      const hour = new Date().getHours();
      const isRush = (hour >= 7 && hour <= 10) || (hour >= 17 && hour <= 20);
      const isNight = hour >= 22 || hour <= 5;
      const cleanOrig = origin.replace(/[^a-zA-Z]/g, '').toLowerCase();
      const cleanDest = dest.replace(/[^a-zA-Z]/g, '').toLowerCase();
      const highDemandCorridor = cleanOrig === 'patna' && ['gaya', 'muzaffarpur', 'darbhanga'].includes(cleanDest);

      let demandScore = 65;
      if (highDemandCorridor) demandScore += 18;
      if (isRush) demandScore += 12;
      if (isNight) demandScore -= 8;
      demandScore = Math.max(40, Math.min(96, demandScore));

      const demandLevel = demandScore >= 80 ? 'HIGH DEMAND' : (demandScore >= 60 ? 'BALANCED' : 'NORMAL');
      const conversionExpected = demandScore >= 75 ? 92 : 85;
      const co2Saved = Math.round(fareData.distanceKm * 0.14 * 10) / 10;

      if (!db.ai_events) db.ai_events = [];
      db.ai_events.push({
        id: `AI_${Date.now()}`,
        type: 'PRICING_INTELLIGENCE',
        route: `${origin} ➔ ${dest}`,
        demandScore,
        fare: fareData.totalFare,
        createdAt: new Date().toISOString()
      });
      saveDb(db);

      return sendJson(200, {
        success: true,
        route: `${origin} to ${dest}`,
        distanceKm: fareData.distanceKm,
        standardFare: fareData.totalFare,
        recommendedFare: fareData.totalFare,
        demandScore,
        demandLevel,
        surgeMultiplier: 1.0,
        surgeCapped: true,
        surgeProtected: true,
        conversionProbability: `${conversionExpected}%`,
        expectedMargin: '18.5%',
        co2SavedKg: co2Saved,
        rationale: highDemandCorridor ? `High corridor volume between ${origin} and ${dest}; fleet positioning optimal.` : 'Stable route demand; guaranteed transparent flat rate.',
        peakPeriod: isRush
      });
    }

    if (pathname === '/admin/driver-matching' && method === 'POST') {
      const { bookingId, originCity = 'Patna' } = body;
      const targetBooking = bookingId ? (db.bookings || []).find(b => b.bookingId === bookingId) : null;
      const pickupCity = targetBooking ? targetBooking.originCity : originCity;
      const requiredTier = targetBooking ? (targetBooking.fleetClass && targetBooking.fleetClass.includes('SUV') ? 'suv' : 'sedan') : 'sedan';

      const matchedDrivers = (db.drivers || []).map(d => {
        let score = 70;
        const reasons = [];

        if (d.status === 'Available') {
          score += 15;
          reasons.push('Chauffeur currently available on dispatch');
        } else {
          score -= 30;
          reasons.push('Chauffeur on active trip');
        }

        if (d.fleetTier === requiredTier) {
          score += 10;
          reasons.push(`Direct vehicle tier match (${d.fleetTier})`);
        } else if (d.fleetTier === 'suv' && requiredTier === 'sedan') {
          score += 5;
          reasons.push(`Vehicle upgrade eligible (${d.fleetTier})`);
        }

        if (d.rating >= 4.8) {
          score += 5;
          reasons.push(`High chauffeur rating (${d.rating}★)`);
        }

        const finalScore = Math.max(40, Math.min(98, score));
        const etaMins = finalScore >= 90 ? 8 : (finalScore >= 80 ? 14 : 22);

        return {
          driverId: d.id,
          name: d.name,
          phone: d.phone,
          vehicleModel: d.vehicleModel,
          vehicleNumber: d.vehicleNumber,
          fleetTier: d.fleetTier,
          rating: d.rating,
          totalTrips: d.totalTrips,
          suitabilityScore: finalScore,
          etaMinutes: etaMins,
          badge: finalScore >= 90 ? `Best Match (${finalScore}%)` : (finalScore >= 80 ? `Recommended (${finalScore}%)` : `Available (${finalScore}%)`),
          reasons
        };
      });

      matchedDrivers.sort((a, b) => b.suitabilityScore - a.suitabilityScore);
      return sendJson(200, {
        success: true,
        bookingId,
        pickupCity,
        recommendations: matchedDrivers,
        matches: matchedDrivers
      });
    }

    if (pathname === '/admin/copilot' && method === 'POST') {
      const rawQuery = (body.query || '').trim().toLowerCase();
      const todayStr = new Date().toISOString().slice(0, 10);
      const todayBookings = (db.bookings || []).filter(b => (b.createdAt || '').startsWith(todayStr));
      const totalBookingsCount = (db.bookings || []).length;
      const activeTrips = (db.bookings || []).filter(b => b.bookingStatus !== 'COMPLETED' && b.bookingStatus !== 'CANCELLED');
      const cancelledBookings = (db.bookings || []).filter(b => b.bookingStatus === 'CANCELLED');

      let totalRev = 0, todayRev = 0, unpaidCount = 0, unpaidAmount = 0;
      (db.payments || []).forEach(p => {
        const amt = parseInt(p.amount) || 0;
        if ((p.status || '').includes('PAID')) {
          totalRev += amt;
          if ((p.createdAt || '').startsWith(todayStr)) todayRev += amt;
        } else {
          unpaidCount++;
          unpaidAmount += amt;
        }
      });

      let answer = '';
      let dataPayload = {};

      if (rawQuery.includes('revenue') || rawQuery.includes('earn') || rawQuery.includes('turnover')) {
        answer = `Today's verified revenue is Rs ${todayRev} across verified transactions. Total platform revenue to date stands at Rs ${totalRev}. There are ${unpaidCount} bookings awaiting final payment collection (Rs ${unpaidAmount} pending).`;
        dataPayload = { todayRevenue: todayRev, totalRevenue: totalRev, unpaidAmount, unpaidCount };
      } else if (rawQuery.includes('booking') || rawQuery.includes('trip') || rawQuery.includes('how many')) {
        const cRate = totalBookingsCount > 0 ? Math.round((cancelledBookings.length / totalBookingsCount) * 100) : 0;
        answer = `Today's total booking requests: ${todayBookings.length}. Active in-progress trips: ${activeTrips.length}. Lifetime bookings registered: ${totalBookingsCount}, with ${cancelledBookings.length} cancellations (${cRate}% cancellation rate).`;
        dataPayload = { todayBookings: todayBookings.length, activeTrips: activeTrips.length, totalBookings: totalBookingsCount, cancelled: cancelledBookings.length };
      } else if (rawQuery.includes('route') || rawQuery.includes('demand') || rawQuery.includes('popular')) {
        answer = `The highest demand corridor is Patna ➔ Gaya with active inquiries and bookings. Other high-density corridors include Patna ➔ Muzaffarpur and Patna ➔ Darbhanga.`;
        dataPayload = { topRoute: 'Patna ➔ Gaya' };
      } else if (rawQuery.includes('unpaid') || rawQuery.includes('pending payment')) {
        answer = `There are ${unpaidCount} unpaid / pending payment transactions totaling Rs ${unpaidAmount}. Recommend dispatchers follow up via WhatsApp or verify driver cash handover.`;
        dataPayload = { unpaidCount, unpaidAmount };
      } else if (rawQuery.includes('vehicle') || rawQuery.includes('fleet') || rawQuery.includes('expir')) {
        const expiring = (db.vehicles || []).filter(v => (v.insuranceExpiry || '') < '2026-10-30');
        answer = `Total registered fleet: ${(db.vehicles || []).length} vehicles. Alert: ${expiring.length} vehicle(s) have insurance/fitness expiring within 60 days.`;
        dataPayload = { totalVehicles: (db.vehicles || []).length, expiringCount: expiring.length, vehicles: expiring };
      } else {
        answer = `Platform Operational Snapshot: ${totalBookingsCount} Total Bookings (${todayBookings.length} today), ${activeTrips.length} Active Rides, Rs ${todayRev} verified revenue today. AI Dispatch running nominal.`;
        dataPayload = { todayBookings: todayBookings.length, activeTrips: activeTrips.length, todayRevenue: todayRev };
      }

      return sendJson(200, {
        success: true,
        query: rawQuery,
        answer,
        data: dataPayload,
        timestamp: new Date().toISOString()
      });
    }

    if (pathname === '/ai/parse-intent' && method === 'POST') {
      const userText = (body.text || '').trim();
      const allCities = loadCities() || [];
      let detectedOrigin = null, detectedDest = null;

      for (const c of allCities) {
        const cName = c.name.toLowerCase();
        if (new RegExp(`from\\s+${cName}`, 'i').test(userText)) detectedOrigin = c;
        else if (new RegExp(`to\\s+${cName}`, 'i').test(userText)) detectedDest = c;
      }

      if (!detectedOrigin || !detectedDest) {
        const found = allCities.filter(c => userText.toLowerCase().includes(c.name.toLowerCase()));
        if (found.length >= 2) {
          if (!detectedOrigin) detectedOrigin = found[0];
          if (!detectedDest) detectedDest = found[1];
        } else if (found.length === 1 && !detectedOrigin) {
          detectedOrigin = found[0];
        }
      }

      if (!detectedOrigin) detectedOrigin = { id: 'patna', name: 'Patna', state: 'Bihar' };
      if (!detectedDest) detectedDest = { id: 'gaya', name: 'Gaya', state: 'Bihar' };

      const isTomorrow = userText.toLowerCase().includes('tomorrow');
      const pDate = new Date();
      if (isTomorrow) pDate.setDate(pDate.getDate() + 1);
      const dateStr = pDate.toISOString().slice(0, 10);

      const paxMatch = userText.match(/(\d+)\s*(people|person|passengers?|pax)/i);
      const pax = paxMatch ? parseInt(paxMatch[1]) : (userText.toLowerCase().includes('family') ? 5 : 1);
      const tripType = (userText.toLowerCase().includes('round') || userText.toLowerCase().includes('return')) ? 'roundtrip' : 'oneway';
      const cabTier = pax > 4 ? 'suv' : 'sedan';
      const fareData = calculateServerFare(detectedOrigin.name, detectedDest.name, cabTier, tripType);

      return sendJson(200, {
        success: true,
        extracted: {
          originCity: detectedOrigin.name,
          destCity: detectedDest.name,
          pickupDate: dateStr,
          pickupTime: '10:00 AM',
          passengers: pax,
          tripType,
          cabTier,
          estimatedFare: fareData.totalFare,
          distanceKm: fareData.distanceKm,
          duration: fareData.duration
        },
        confirmationPrompt: `I've configured a ${tripType} ride from ${detectedOrigin.name} to ${detectedDest.name} on ${dateStr} for ${pax} passenger(s) in a ${cabTier} (Estimated: Rs ${fareData.totalFare}). Would you like to review and book?`
      });
    }

    if (pathname === '/ai/support' && method === 'POST') {
      const query = (body.message || '').trim().toLowerCase();
      const phone = (body.phone || '').replace(/\D/g, '').slice(-10);

      let reply = '', action = null, escalate = false;

      if (/otb-\d{4}-\d+/i.test(query) || (phone && (query.includes('where') || query.includes('status') || query.includes('track')))) {
        const match = query.match(/(otb-\d{4}-\d+)/i);
        const bId = match ? match[1].toUpperCase() : '';
        const found = bId 
          ? (db.bookings || []).find(b => b.bookingId === bId)
          : (phone ? (db.bookings || []).find(b => b.passengerPhone && b.passengerPhone.includes(phone)) : null);

        if (found) {
          const drv = found.driverDetails ? `${found.driverDetails.name} (${found.driverDetails.phone})` : 'Driver assignment in progress';
          reply = `Booking ${found.bookingId} (${found.originCity} ➔ ${found.destCity}) status: ${found.bookingStatus}. Chauffeur: ${drv}. Schedule: ${found.pickupDate} at ${found.pickupTime}.`;
          action = { type: 'VIEW_TRIP', bookingId: found.bookingId };
        } else {
          reply = "I couldn't find an active booking for that reference. Please check the 10-digit mobile number or Booking ID.";
        }
      } else if (query.includes('cancel') || query.includes('refund')) {
        reply = "OneWayTaxiBihar offers 100% Free Cancellation with Rs 0 fee before chauffeur dispatch. Any wallet balance or payment is automatically refunded immediately.";
      } else if (query.includes('toll') || query.includes('include') || query.includes('charge')) {
        reply = "All OneWayTaxiBihar fares are 100% all-inclusive: Base vehicle charge, State Tolls & FASTag, Driver Allowance, and 5% GST are included. No return fare is charged on one-way trips.";
      } else if (query.includes('reward') || query.includes('wallet') || query.includes('100')) {
        reply = "Every verified passenger receives a one-time Rs 100 Welcome Bonus credited directly to their wallet upon mobile verification, redeemable immediately on first booking.";
      } else if (query.includes('invoice') || query.includes('gst')) {
        reply = "You can download GST-compliant tax invoices anytime under 'My Trips' ➔ 'View Tax Invoice' with your company GSTIN.";
      } else {
        reply = "I am your OneWayTaxiBihar AI Mobility Assistant. You can ask me to book a cab, check live ride status, inquire about fares, or connect to our 24x7 Patna Dispatch Desk.";
        escalate = true;
      }

      return sendJson(200, {
        success: true,
        reply,
        action,
        helpline: '+91 80021 41816',
        whatsappUrl: `https://wa.me/917281851011?text=${encodeURIComponent(`Support Inquiry: ${query}`)}`,
        escalate
      });
    }

    if (pathname === '/coupons/apply' && method === 'POST') {
      const codeInput = (body.code || '').trim().toUpperCase();
      const fareAmount = parseInt(body.fareAmount) || 1500;
      const cpn = (db.coupons || []).find(c => c.code.toUpperCase() === codeInput && c.active);

      if (!cpn) return sendJson(404, { success: false, message: `Invalid or expired coupon code: '${codeInput}'` });
      if (fareAmount < cpn.minFare) return sendJson(400, { success: false, message: `Coupon '${codeInput}' requires a minimum fare of Rs ${cpn.minFare}.` });

      let discount = 0;
      if (cpn.type === 'PERCENT') {
        const calc = Math.round((fareAmount * cpn.discount) / 100);
        discount = Math.min(calc, cpn.maxDiscount);
      } else {
        discount = Math.min(cpn.discount, fareAmount);
      }

      return sendJson(200, {
        success: true,
        valid: true,
        code: cpn.code,
        discount,
        title: cpn.title,
        message: `Coupon '${cpn.code}' applied! You saved Rs ${discount}.`
      });
    }

    if (pathname === '/admin/coupons' && method === 'GET') {
      return sendJson(200, { success: true, coupons: db.coupons || [] });
    }

    if (pathname === '/admin/coupons/create' && method === 'POST') {
      const newCpn = {
        code: (body.code || '').trim().toUpperCase(),
        title: body.title,
        type: body.type || 'FLAT',
        discount: parseInt(body.discount) || 50,
        minFare: parseInt(body.minFare) || 800,
        maxDiscount: parseInt(body.maxDiscount) || 100,
        description: body.description,
        expiry: body.expiry || '2026-12-31',
        usageCount: 0,
        active: true
      };
      if (!db.coupons) db.coupons = [];
      db.coupons.push(newCpn);
      saveDb(db);
      return sendJson(200, { success: true, coupon: newCpn });
    }

    if (pathname === '/admin/vehicles' && method === 'GET') {
      const todayDate = new Date();
      const enriched = (db.vehicles || []).map(v => {
        const insExp = v.insuranceExpiry ? new Date(v.insuranceExpiry) : new Date(todayDate.getTime() + 365*86400000);
        const daysToIns = Math.round((insExp - todayDate) / 86400000);
        let alert = null;
        if (daysToIns < 0) alert = 'INSURANCE EXPIRED';
        else if (daysToIns <= 30) alert = `Insurance Expiring in ${daysToIns} days`;

        return { ...v, documentAlert: alert };
      });
      return sendJson(200, { success: true, vehicles: enriched, count: enriched.length });
    }

    if (pathname === '/admin/vehicles/add' && method === 'POST') {
      const newVeh = {
        id: `veh_${Math.floor(10 + Math.random() * 90)}`,
        regNumber: (body.regNumber || '').trim().toUpperCase(),
        model: body.model,
        category: body.category || 'sedan',
        seatingCapacity: parseInt(body.seatingCapacity) || 4,
        hasAC: true,
        fuelType: body.fuelType || 'CNG / Petrol',
        assignedDriverId: body.assignedDriverId || null,
        status: 'ACTIVE',
        insuranceExpiry: body.insuranceExpiry || '2027-04-10',
        fitnessExpiry: body.fitnessExpiry || '2027-05-15',
        permitExpiry: body.permitExpiry || '2027-08-20'
      };
      if (!db.vehicles) db.vehicles = [];
      db.vehicles.push(newVeh);
      saveDb(db);
      return sendJson(200, { success: true, vehicle: newVeh });
    }

    if (pathname === '/admin/fraud-check' && method === 'POST') {
      const phone = (body.phone || '').replace(/\D/g, '').slice(-10);
      const bId = body.bookingId;
      const b = bId ? (db.bookings || []).find(x => x.bookingId === bId) : null;
      const targetPhone = b ? (b.passengerPhone || '').replace(/\D/g, '').slice(-10) : phone;

      const cancels = (db.bookings || []).filter(x => (x.passengerPhone || '').includes(targetPhone) && x.bookingStatus === 'CANCELLED').length;
      let score = 8;
      const flags = [];
      if (cancels >= 3) { score += 40; flags.push(`High cancellation rate (${cancels} cancelled bookings)`); }
      else if (cancels >= 1) { score += 15; flags.push(`Prior cancelled booking (${cancels})`); }

      const riskLevel = score >= 60 ? 'HIGH RISK' : (score >= 30 ? 'MEDIUM RISK' : 'LOW RISK (NORMAL)');
      const action = score >= 60 ? 'Require token advance before driver dispatch' : (score >= 30 ? 'Dispatcher phone confirmation required' : 'Auto-eligible for rapid chauffeur assignment');

      return sendJson(200, {
        success: true,
        targetPhone: `+91 ${targetPhone}`,
        riskScore: score,
        riskLevel,
        flags,
        recommendedAction: action
      });
    }

    // Default 404 for unknown API routes
    return sendJson(404, { success: false, message: 'API route not found' });

  } catch (err) {
    console.error('[API Error]:', err);
    return sendJson(500, { success: false, message: 'Internal server error', error: err.message });
  }
};
